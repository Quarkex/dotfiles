#!/bin/bash
execPath="${PWD%/}";
projectname="${execPath##*/}";

user=$(getent passwd $USER);
user=$(echo "$user" | cut -d ':' -f 5);
user=$(echo "$user" | cut -d ',' -f 1);

rm index.tex index.content.tex;
touch index.tex &&
touch index.content.tex &&
echo "\input{preamble}" > index.tex &&

echo "\begin{document}" >> index.tex &&

echo "\title{$projectname}" >> index.tex &&

echo "\author{$user}" >> index.tex &&

echo "\maketitle" >> index.tex &&

echo "\tableofcontents{}" >> index.tex &&

for i in tex/*.tex; do
    echo "\input{${i%.tex}}" >> index.content.tex;
done &&

echo "\include{index.content}" >> index.tex &&

echo "\end{document}" >> index.tex;


pdflatex index.tex &&
pdflatex index.tex &&
mv index.pdf output.pdf &&
rm index.out index.log index.toc index.aux &&
rm tex/*.aux *.aux index.tex index.content.tex
