#!/bin/bash
pdflatex index.tex &&
pdflatex index.tex &&
mv index.pdf output.pdf &&
rm index.out index.log index.toc *.aux 
